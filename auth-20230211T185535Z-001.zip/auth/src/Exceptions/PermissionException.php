<?php

namespace Myth\Auth\Exceptions;

use RuntimeException;

class PermissionException extends RuntimeException implements ExceptionInterface
{
}
